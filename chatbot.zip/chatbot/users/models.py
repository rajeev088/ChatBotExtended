from django.db import models


class Groups(models.Model):
    group = models.CharField(max_length=30)
    group_description = models.CharField(max_length=4000)

    def __str__(self):
        return self.group

    class Meta:
        ordering = ('group_description',)


class Questions(models.Model):
    question = models.CharField(max_length=30)
    question_description = models.CharField(max_length=4000)
    question_group = models.ForeignKey(Groups, on_delete=models.CASCADE)

    def __str__(self):
        return self.question

    class Meta:
        ordering = ('question_description',)


class Answers(models.Model):
    answer = models.CharField(max_length=100)
    answers_description = models.CharField(max_length=4000)
    answer_group = models.ForeignKey(Groups, on_delete=models.CASCADE)

    def __str__(self):
        return self.answer

    class Meta:
        ordering = ('answers_description',)

