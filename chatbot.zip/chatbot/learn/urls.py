from django.urls import path

from .views import RecipeCreateView


app_name = 'books'

urlpatterns = [

    path('demohome/',
         RecipeCreateView.as_view(),
        name='newhome'),
]
