from django.forms import ModelForm
from django.forms.models import inlineformset_factory

from .models import Recipe, Ingredient, Instruction


class RecipeForm(ModelForm):
    class Meta:
        model = Recipe
        exclude = ()


IngredientFormSet = inlineformset_factory(Recipe, Ingredient,form=RecipeForm)
InstructionFormSet = inlineformset_factory(Recipe, Instruction,form=RecipeForm)