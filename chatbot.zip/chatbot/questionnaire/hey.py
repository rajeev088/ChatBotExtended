"""select * from question a,ansers b
where a.group=b.group
and a.group=2"""