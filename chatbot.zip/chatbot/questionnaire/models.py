from django.db import models
from django.utils.timezone import now


class Groups(models.Model):
    class Meta:
        verbose_name_plural = "Groups"

    group = models.CharField(max_length=30)
    group_description = models.CharField(max_length=4000,default=None,null=True)
    group_date = models.DateTimeField(blank=True, null=True)
    print("In model")

    def __str__(self):
        return self.group

    def save(self,*args,**kwargs):
        if(self.group and self.group_date is None):
            self.group_date=now()

        super(Groups,self).save(*args,**kwargs)


class Questions(models.Model):
    class Meta:
        verbose_name_plural = "Questions"

    question = models.CharField(max_length=30,verbose_name="Input Question")
    question_description = models.CharField(max_length=4000 ,default=None)
    question_date=models.DateTimeField(blank=True,null=True)
    question_group = models.ForeignKey(Groups, on_delete=models.CASCADE)

    def __str__(self):
        return self.question

    def save(self,*args,**kwargs):
        if(self.question and self.question_date is None):
            self.question_date=now()

        super(Questions,self).save(*args,**kwargs)


class Answers(models.Model):
    class Meta:
        verbose_name_plural = "Answers"

    answer = models.CharField(max_length=100,verbose_name="Your Answer")
    answers_description = models.CharField(max_length=4000,default=None,help_text="",blank=True,null=True)
    answer_date = models.DateTimeField(blank=True, null=True)
    answer_group = models.ForeignKey(Groups, on_delete=models.CASCADE,blank=True)
    #valid_question = models.ManyToManyField("Questions",related_name="answers")
    print("Model Called")

    def __str__(self):
        return self.answer

    def save(self,*args,**kwargs):
        if(self.answer and self.answer_date is None):
            self.answer_date=now()

        super(Answers,self).save(*args,**kwargs)

