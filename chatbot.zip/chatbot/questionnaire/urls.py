from django.conf.urls import url

from .views import lists, load_questions
from django.urls import path

urlpatterns = [
    url(r'lists', lists, name="lists"),
path('ajax/load_questions/', load_questions, name='load_questions'),
]