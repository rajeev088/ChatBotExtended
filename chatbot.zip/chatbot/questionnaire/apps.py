from django.apps import AppConfig


class QuestionnaireConfig(AppConfig):
    name = 'questionnaire'
