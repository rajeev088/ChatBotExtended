from django.forms import inlineformset_factory,Textarea,BaseFormSet
from django.forms.models import modelformset_factory

from .models import Groups,Questions,Answers
from django import forms
from django.http import request
from django.forms import formset_factory


class groupForm(forms.Form):
    group = forms.CharField(label="Group",max_length=100)

    def choices(self):
        a=[('','Select a Group')]
        return a+[ (o.id, str(o)) for o in Groups.objects.all()]

    def __init__(self, *args, **kwargs):
        super(groupForm, self).__init__(*args, **kwargs)
        print([(o.id, str(o)) for o in Groups.objects.all()])
        print(type([(o.id, str(o)) for o in Groups.objects.all()]))
        self.fields['group'] = forms.ChoiceField(
            choices=self.choices(),
            required=True,
        )
        #self.fields['group'].label = "Select Group"

"""
class questionForm(forms.Form):
    question = forms.CharField(min_length=2, label="Questions",
                               widget=forms.TextInput(attrs={
                                   'size': '40',
                                   'placeholder':'Add Question'
                               }))
    question_description = forms.CharField(max_length=100, label="Q-Desc",initial='Description Here',required=False)



class answerForm(forms.Form):
    answer = forms.CharField(min_length=2,label="Ans",
                             widget=forms.TextInput(attrs={'size': '40','placeholder':'Add Answers'}))
    answer_description = forms.CharField(widget=forms.Textarea,initial='Description Here',required=False)
    print("in forms")


class RequiredFormSet(BaseFormSet):
    def __init__(self, *args, **kwargs):
        super(RequiredFormSet, self).__init__(*args, **kwargs)
        for form in self.forms:
            form.empty_permitted = False


MyFormSets = inlineformset_factory(
        Groups,Answers, extra=10,fields=('answer',),
        widgets={'name': Textarea(attrs={'cols': 80, 'rows': 40})}
    )
MyFormSets1 = formset_factory(answerForm, formset=RequiredFormSet,extra=1 )
"""

from crispy_forms.helper import FormHelper, Layout


class questionForm(forms.ModelForm):

    class Meta:
        model = Questions
        #fields = ['question', 'question_description',]
        exclude = ()


questionFormSet = modelformset_factory(Questions, form=questionForm, extra=1)



class answerForm(forms.ModelForm):

    class Meta:
        model = Groups
        exclude = ()


    def add_fields(self, form, index):
        """A hook for adding extra fields on to each form instance."""
        super(answerForm, self).add_fields(form, index)
        # here call a custom method or perform any other required action
        form.set_index(index)


#answerFormSet = modelformset_factory(Answers, form=answerForm, extra=1)

questionFormSet = inlineformset_factory(Groups, Questions,form=answerForm)
answerFormSet = inlineformset_factory(Groups, Answers,form=answerForm)
#myFormset=questionFormSet|answerFormSet


class MyFormSetHelper(FormHelper):
    def __init__(self, *args, **kwargs):
        super(MyFormSetHelper, self).__init__(*args, **kwargs)
        self.layout = Layout(
            'questionForm',
            'answerForm',
            'question',
            'question_description',
        )
        self.template = 'bootstrap/table_inline_formset.html'

