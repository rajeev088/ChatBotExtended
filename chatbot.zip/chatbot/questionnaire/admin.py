from django.contrib import admin
from .models import Groups, Questions, Answers

# Register your models here.
admin.site.register(Groups)


@admin.register(Questions)
class QuestionAdmin(admin.ModelAdmin):
    fieldsets = [
        ("Group",{"fields":["question_group"]}),
        ("Question", {"fields": ["question","question_description"]}),
        ("Date", {"fields": ["question_date"]})
    ]

    readonly_fields = ["question_date"]
    list_display = ("question","question_description","question_date","question_group",)
    list_editable = ("question_group",)
    list_display_links = ("question",)
    list_filter = ("question_group",)
    search_fields = ("question", )



@admin.register(Answers)
class AnswerAdmin(admin.ModelAdmin):
    fieldsets = [
        ("Group",{"fields":["answer_group"]}),
        ("Answer", {"fields": ["answer","answers_description"]}),
        ("Date", {"fields": ["answer_date"]})
    ]

    readonly_fields = ["answer_date"]
    list_display = ("answer","answers_description","answer_date","answer_group",)
    list_editable = ("answer_group",)
    list_display_links = ("answer",)
    list_filter = ("answer_group",)
    search_fields = ("answer", )

    #answer.short_description="asdadsad"



