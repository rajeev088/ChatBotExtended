from django.shortcuts import render, redirect
from .models import Answers, Questions, Groups
# Create your views here.

from django.forms import ModelForm, Textarea
from .forms import groupForm,questionFormSet,answerFormSet,MyFormSetHelper#,MyFormSets,questionForm,answerForm
from django.http import JsonResponse
from django.forms import formset_factory
from django.forms import inlineformset_factory


def lists(request):
    """

    :param request:
    :return:
    """

    print("req- "+request.method)
    #answers = Answers.objects.none()
    #groups = Groups.objects.all()



    if request.method == 'POST':
        questionsform = questionFormSet(request.POST)
        answersform = answerFormSet(request.POST)
        groupsform = groupForm(request.POST)
        print(answersform.is_valid())
        print(answersform.errors.as_data())
        #print(questionsform.is_valid())

        if answersform.is_valid() and groupsform.is_valid() and questionsform.is_valid():
            #Answers.answer = answersform.cleaned_data['answer']
            #Answers.answer_group = groupsform.cleaned_data['group']
            print("in views")
            print(answersform.cleaned_data)
            #print(questionsform.cleaned_data)
            print(type(groupsform.cleaned_data))


            a=Answers(answer=answersform.cleaned_data['answer'],
                      answers_description="",
                      answer_group=Groups(groupsform.cleaned_data['group']))
            a.save()
            q = Questions(question=questionsform.cleaned_data['question'],
                          question_description="",
                          question_group=Groups(groupsform.cleaned_data['group']))
            q.save()
            return redirect('lists')
        else:
            return redirect('chatbot_welcome')
    else:
        #formset = MyFormSets
        #formsets = answerFormSet
        #helper = MyFormSetHelper
        #print('formsets',formsets)
        #print('helper',helper)

        context = {
            'groups': groupForm,
            'questions': questionFormSet,
            'answers': answerFormSet,
            #'formsets':formsets,
            #'helper': helper,
            #'formset':formset,
        }

    return render(request, 'lists.html', context)


def load_questions(request):
    group_id = request.GET.get ('groupId')
    data = {
        "Table": {
            "TR": [
            ]
        }
    }
    if group_id is not None:
        questions = (Questions.objects.filter(question_group=group_id).values("question", "question_group"))
        answers = (Answers.objects.filter(answer_group=group_id).values("answer", "answer_group"))

        l_len = len(questions) if len(questions) >= len(answers) else len(answers)#lambda can be used here

        for i in range(l_len):

            try:
                if list(questions)[i]["question"]:
                    q=list(questions)[i]["question"]
            except:
                q=''
            try:
                if list(answers)[i]["answer"]:
                    a=list(answers)[i]["answer"]
            except:
                a=''

            data["Table"]["TR"].append({
                "row": i+1,
                "group": group_id,
                "question": q,
                "Answer": a
            })
        print(data)
        return JsonResponse(data)
    else:
        return JsonResponse(data)


def load_questions_dummy(request):
    group_id = request.GET.get('groupId')

    """
    questions = Questions.objects.filter(question_group=group_id)
    answers = Answers.objects.filter(answer_group=group_id)
    print(answers)
    print(questions)
    questions_as_dict = []

    for qu in questions:
        question_as_dict = {
            "question": qu.question,
            #'question_description': Questions.question_description,
            "question_group": qu.question_group}
        questions_as_dict.append(question_as_dict)

    print(questions_as_dict)
    answers_as_dict = []

    for ans in answers:
        answer_as_dict = {
            "answer": ans.answer,
            # 'question_description': Questions.question_description,
            "answer_group": ans.answer_group}
        answers_as_dict.append(answer_as_dict)

    print(answers_as_dict)

    """

    import json

    questions = (Questions.objects.filter(question_group=group_id).values("question", "question_group"))
    # print(list(questions)[0]["question"])
    # print(list(questions)["question"][0])
    json_questions = json.dumps(list(questions))
    # print(json_questions)
    answers = (Answers.objects.filter(answer_group=group_id).values("answer", "answer_group"))
    # print(answers)
    # print(list(answers)[1]["answer"])
    json_answers = json.dumps(list(answers))

    """
var data={'answers': '[{"answer": "hey", "answer_group": 3}, {"answer": "heyy", "answer_group": 3}]',
                 'questions': '[{"question": "heyy", "question_group": 3}]'
                }

    """

    data = {
        'answers': json_answers,
        "questions": json_questions,
        # 'answers': answerForm,
        # 'questions': questionForm,
    }
    questions1 = (Questions.objects.filter(question_group=group_id).values("question", "question_group"))
    # print(len(list(questions1)))
    answers1 = (Answers.objects.filter(answer_group=group_id).values("answer", "answer_group"))

    # l_len=len(questions1) if questions1>=answers1 else len(answers1)
    l_len = 0
    if len(questions1) >= len(answers1):
        l_len = 1
    else:
        l_len = 2

    data = {
        "Table": {
            "TR": [
                """
                {
                    "row": 1,
                    "group": group_id,
                    "question": "heyy",
                    "Answer": "hey"
                },
                {
                    "row": 2,
                    "group": group_id,
                    "question": "y",
                    "Answer": "heyy"
                }
                """
            ]
        }
    }

    data = {
        "Table": {
            "TR": [

            ]
        }
    }

    print(data["Table"]["TR"].append({
        "row": 1,
        "group": group_id,
        "question": list(questions)[0]["question"],
        "Answer": list(answers)[0]["answer"]
    }))

    if l_len == 1:
        for i in answers:
            data["Table"]["TR"].append({
                "row": i,
                "group": group_id,
                "question": list(questions)[i - 1]["question"],
                "Answer": list(answers)[i - 1]["answer"]
            })
    else:
        for i in questions:
            print(list(questions)[i - 1]["question"])
            data["Table"]["TR"].append({
                "row": i,
                "group": group_id,
                "question": list(questions)[i - 1]["question"] if list(questions)[i - 1][
                                                                      "question"] is not None else "",
                "Answer": list(answers)[i - 1]["answer"]
            })

    print(data)
    return JsonResponse(data)
